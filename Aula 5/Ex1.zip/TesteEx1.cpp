#include "Musica.h"

#include <string>
#include <iostream>
using namespace std;

void teste() {
    Musica *m = new Musica(180, "Roses");
    m -> imprimir();
}

/*
int main() {
    teste();
    return 0;
}
*/