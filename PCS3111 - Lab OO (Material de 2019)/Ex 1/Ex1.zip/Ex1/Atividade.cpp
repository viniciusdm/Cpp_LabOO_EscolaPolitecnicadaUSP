#include "Atividade.h"


Atividade::Atividade(string nome, int horasNecessarias, int maximoPessoas) : nome(nome),
                     horasNecessarias(horasNecessarias), maximoPessoas(maximoPessoas) {

    if (horasNecessarias <= 0)
        throw new invalid_argument("horas necessarias < ou = 0");
    else if (maximoPessoas <= 0)
        throw new invalid_argument("maximoPessoas < ou = 0");

    this->pessoas = new Pessoa*[maximoPessoas];
    this->quantidade = 0;
}

Atividade::~Atividade() {
    for (int i = 0; i < quantidade; i++) {
        delete pessoas[i];
    }
    delete[] pessoas;
}

int Atividade::getHorasNecessarias() {
    return horasNecessarias;
}

void Atividade::adicionar(Pessoa* p) { //alterei bool para void
    if (p == NULL)
        throw new invalid_argument ("pessoa invalida");
    else if (quantidade == maximoPessoas)
        throw new overflow_error ("vetor pessoas esta cheio");

    if (quantidade < maximoPessoas) {
        pessoas[quantidade++] = p;
        //return true; // sem retorno
    }
    //return false; // sem retorno
}

int Atividade::getDuracao() {
    if (quantidade < 1)
        throw new logic_error ("nao existe pessoas adicionadas");

    double horas = 0;

    if (quantidade == 0)
        return -1;

    for (int i = 0; i < quantidade; i++)
        horas += pessoas[i]->getHorasDiarias();

    return ceil(horasNecessarias/horas);
}

void Atividade::imprimir() {
    cout << nome << " - " << getDuracao() << " dias estimados" << endl;
    for (int i = 0; i < quantidade; i++)
        pessoas[i]->imprimir();
    cout << endl;
}

